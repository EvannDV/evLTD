ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockTech9 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750

                for k in pairs {vector3(-1486.2418212891,-379.91870117188,40.187210083008)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(-1486.2418212891,-379.91870117188,40.187210083008)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, -1486.2418212891,-379.91870117188,40.187210083008-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 174, 219, 242, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au rayon")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        ESX.TriggerServerCallback('ev:rayontech9', function(item)
                            evStockTech9 = item
                        end)
                        evLtdTech9()
                    end
                end

            end

    Citizen.Wait(wait)
    end
end)








function evLtdTech9()

    local evLtdTech99 = RageUI.CreateMenu("Rayon Tech", "intéractions")

    RageUI.Visible(evLtdTech99, not RageUI.Visible(evLtdTech99))

    while evLtdTech99 do


        Citizen.Wait(0)
        RageUI.IsVisible(evLtdTech99, true, true, true, function()

            if #evStockTech9 >= 1 then
                RageUI.Separator("~g~↓~s~   En vente   ~g~↓~s~")

                for k,v in pairs(evStockTech9) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "~g~"..v.price.." $"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            local loca = "Ltd 9"
                            TriggerServerEvent('ev:BuyLtd', v.price, v.item, cb, v.label, loca)

                        end
                    end)
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd9' then
                        RageUI.ButtonWithStyle("Définir le prix de : ~r~"..v.label, nil, {RightLabel = "🔓"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                priceDefine = Keyboard("Combien ?", "",20)
                                RageUI.CloseAll()
                                local loca = "Ltd 9"
                                TriggerServerEvent('ev:AddPrice', priceDefine, v.item, loca)

                            end
                        end)
                    end
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end





        
        end)
        if not RageUI.Visible(evLtdTech99) then
            evLtdTech99=RMenu:DeleteType("evLtdTech99", true)

        end
    end
end
