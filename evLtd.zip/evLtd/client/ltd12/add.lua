ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockEat12 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd12' then
                for k in pairs {vector3(-3039.4360351563,584.32507324219,7.9089283943176)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(-3039.4360351563,584.32507324219,7.9089283943176)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, -3039.4360351563,584.32507324219,7.9089283943176-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 0, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au panel")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        evAddEat12()
                    end
                end
            end
            end

    Citizen.Wait(wait)
    end
end)




------------ Menu Add Items 


function evAddEat12()

    local addeat12 = RageUI.CreateMenu("Panel des Stocks", "intéractions")
    local subnourri212 = RageUI.CreateSubMenu(addeat12, "Rayon Nourriture", "intéractions")
    local subinv212 = RageUI.CreateSubMenu(subnourri212, "Votre inventaire", "intéractions")
    local subinv312 = RageUI.CreateSubMenu(subinv212, "Votre inventaire", "intéractions")
    local subboi112 = RageUI.CreateSubMenu(addeat12, "Rayon Boissons", "intéractions")
    local subinv212boi112 = RageUI.CreateSubMenu(subboi112, "Votre inventaire", "intéractions")
    local subinv212boi112212 = RageUI.CreateSubMenu(subinv212boi112, "Votre inventaire", "intéractions")
    local subtech212 = RageUI.CreateSubMenu(addeat12, "Rayon Boissons", "intéractions")
    local subtech2122912 = RageUI.CreateSubMenu(subtech212, "Votre inventaire", "intéractions")
    local subtech2122912212 = RageUI.CreateSubMenu(subtech2122912, "Votre inventaire", "intéractions")
    local subretirNour212 = RageUI.CreateSubMenu(subnourri212, "Rayon Nourriture", "intéractions")
    local subboi22212 = RageUI.CreateSubMenu(subboi112, "Rayon Boissons", "intéractions")
    local subtech212RRR12 = RageUI.CreateSubMenu(subtech212, "Rayon Tech", "intéractions")
    
    
    
    
    

    
    RageUI.Visible(addeat12, not RageUI.Visible(addeat12))

    while addeat12 do


        Citizen.Wait(0)
        RageUI.IsVisible(addeat12, true, true, true, function()




                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Nourriture", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subnourri212)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Boissons", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subboi112)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Tech", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subtech212)


        
        end)

        RageUI.IsVisible(subnourri212, true, true, true, function()



            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv212)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayoneat12', function(item)
                        evStockEat12 = item
                    end)
                end
            end, subretirNour212)
            RageUI.Line()



        end)  
        
        RageUI.IsVisible(subinv212, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv312)
                end
            end



        end)

        RageUI.IsVisible(subinv312, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "nourriture"
                    local loca = "Ltd 12"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subboi112, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv212boi112)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayonboi12', function(item)
                        evStockBoi = item
                    end)
                end
            end, subboi22212)
            RageUI.Line()




        end)

        RageUI.IsVisible(subinv212boi112, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv212boi112212)
                end
            end



        end)


        RageUI.IsVisible(subinv212boi112212, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "boissons"
                    local loca = "Ltd 12"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subtech212, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subtech2122912)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayontech12', function(item)
                        evStockTech = item
                    end)
                end
            end, subtech212RRR12)
            RageUI.Line()




        end)

        RageUI.IsVisible(subtech2122912, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subtech2122912212)
                end
            end



        end)

        RageUI.IsVisible(subtech2122912212, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "tech"
                    local loca = "Ltd 12"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subretirNour212, true, true, true, function()


            if #evStockEat12 >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockEat12) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subboi22212, true, true, true, function()


            if #evStockBoi >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockBoi) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subtech212RRR12, true, true, true, function()


            if #evStockTech >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockTech) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)


        
        

        if not RageUI.Visible(addeat12) and not RageUI.Visible(subnourri212) and not RageUI.Visible(subinv212) and not RageUI.Visible(subinv312) and not RageUI.Visible(subboi112) and not RageUI.Visible(subinv212boi112) and not RageUI.Visible(subinv212boi112212) and not RageUI.Visible(subtech212) and not RageUI.Visible(subtech2122912) and not RageUI.Visible(subtech2122912212) and not RageUI.Visible(subretirNour212) and not RageUI.Visible(subboi22212) and not RageUI.Visible(subtech212RRR12) then
            addeat12=RMenu:DeleteType("addeat12", true)

        end
    end
end





----------Fonction Keyboard


function Keyboard(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end


