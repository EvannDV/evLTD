ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockEat3 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd3' then
                for k in pairs {vector3(1134.3302001953,-983.04864501953,46.415866851807)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(1134.3302001953,-983.04864501953,46.415866851807)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 1134.3302001953,-983.04864501953,46.415866851807-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 0, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au panel")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        evAddEat3()
                    end
                end
            end
            end

    Citizen.Wait(wait)
    end
end)




------------ Menu Add Items 


function evAddEat3()

    local addeat3 = RageUI.CreateMenu("Panel des Stocks", "intéractions")
    local subnourri23 = RageUI.CreateSubMenu(addeat3, "Rayon Nourriture", "intéractions")
    local subinv23 = RageUI.CreateSubMenu(subnourri23, "Votre inventaire", "intéractions")
    local subinv33 = RageUI.CreateSubMenu(subinv23, "Votre inventaire", "intéractions")
    local subboi13 = RageUI.CreateSubMenu(addeat3, "Rayon Boissons", "intéractions")
    local subinv23boi13 = RageUI.CreateSubMenu(subboi13, "Votre inventaire", "intéractions")
    local subinv23boi1323 = RageUI.CreateSubMenu(subinv23boi13, "Votre inventaire", "intéractions")
    local subtech23 = RageUI.CreateSubMenu(addeat3, "Rayon Boissons", "intéractions")
    local subtech2323 = RageUI.CreateSubMenu(subtech23, "Votre inventaire", "intéractions")
    local subtech232323 = RageUI.CreateSubMenu(subtech2323, "Votre inventaire", "intéractions")
    local subretirNour23 = RageUI.CreateSubMenu(subnourri23, "Rayon Nourriture", "intéractions")
    local subboi2223 = RageUI.CreateSubMenu(subboi13, "Rayon Boissons", "intéractions")
    local subtech23RRR3 = RageUI.CreateSubMenu(subtech23, "Rayon Tech", "intéractions")
    
    
    
    
    

    
    RageUI.Visible(addeat3, not RageUI.Visible(addeat3))

    while addeat3 do


        Citizen.Wait(0)
        RageUI.IsVisible(addeat3, true, true, true, function()




                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Nourriture", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subnourri23)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Boissons", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subboi13)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Tech", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subtech23)


        
        end)

        RageUI.IsVisible(subnourri23, true, true, true, function()



            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv23)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayoneat3', function(item)
                        evStockEat3 = item
                    end)
                end
            end, subretirNour23)
            RageUI.Line()



        end)  
        
        RageUI.IsVisible(subinv23, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv33)
                end
            end



        end)

        RageUI.IsVisible(subinv33, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "nourriture"
                    local loca = "Ltd 3"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subboi13, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv23boi13)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayonboi3', function(item)
                        evStockBoi = item
                    end)
                end
            end, subboi2223)
            RageUI.Line()




        end)

        RageUI.IsVisible(subinv23boi13, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv23boi1323)
                end
            end



        end)


        RageUI.IsVisible(subinv23boi1323, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "boissons"
                    local loca = "Ltd 3"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subtech23, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subtech2323)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayontech3', function(item)
                        evStockTech = item
                    end)
                end
            end, subtech23RRR3)
            RageUI.Line()




        end)

        RageUI.IsVisible(subtech2323, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subtech232323)
                end
            end



        end)

        RageUI.IsVisible(subtech232323, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "tech"
                    local loca = "Ltd 3"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subretirNour23, true, true, true, function()


            if #evStockEat3 >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockEat3) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subboi2223, true, true, true, function()


            if #evStockBoi >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockBoi) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subtech23RRR3, true, true, true, function()


            if #evStockTech >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockTech) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)


        
        

        if not RageUI.Visible(addeat3) and not RageUI.Visible(subnourri23) and not RageUI.Visible(subinv23) and not RageUI.Visible(subinv33) and not RageUI.Visible(subboi13) and not RageUI.Visible(subinv23boi13) and not RageUI.Visible(subinv23boi1323) and not RageUI.Visible(subtech23) and not RageUI.Visible(subtech2323) and not RageUI.Visible(subtech232323) and not RageUI.Visible(subretirNour23) and not RageUI.Visible(subboi2223) and not RageUI.Visible(subtech23RRR3) then
            addeat3=RMenu:DeleteType("addeat3", true)

        end
    end
end





----------Fonction Keyboard


function Keyboard(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end


