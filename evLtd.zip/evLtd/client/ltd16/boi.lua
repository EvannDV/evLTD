ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockBoi16 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750

                for k in pairs {vector3(1169.0250244141,2707.5922851563,38.157703399658)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(1169.0250244141,2707.5922851563,38.157703399658)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 1169.0250244141,2707.5922851563,38.157703399658-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 174, 219, 242, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au rayon")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        ESX.TriggerServerCallback('ev:rayonboi16', function(item)
                            evStockBoi16 = item
                        end)
                        evLtd2Boi16()
                    end
                end

            end

    Citizen.Wait(wait)
    end
end)








function evLtd2Boi16()

    local evLtdBoi2216 = RageUI.CreateMenu("Rayon Boissons", "intéractions")

    RageUI.Visible(evLtdBoi2216, not RageUI.Visible(evLtdBoi2216))

    while evLtdBoi2216 do


        Citizen.Wait(0)
        RageUI.IsVisible(evLtdBoi2216, true, true, true, function()

            if #evStockBoi16 >= 1 then
                RageUI.Separator("~g~↓~s~   En vente   ~g~↓~s~")

                for k,v in pairs(evStockBoi16) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "~g~"..v.price.." $"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            local loca = "Ltd 16"
                            TriggerServerEvent('ev:BuyLtd', v.price, v.item, cb, v.label, loca)

                        end
                    end)
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd16' then
                        RageUI.ButtonWithStyle("Définir le prix de : ~r~"..v.label, nil, {RightLabel = "🔓"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                priceDefine = Keyboard("Combien ?", "",20)
                                RageUI.CloseAll()
                                local loca = "Ltd 16"
                                TriggerServerEvent('ev:AddPrice', priceDefine, v.item, loca)

                            end
                        end)
                    end
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end





        
        end)
        if not RageUI.Visible(evLtdBoi2216) then
            evLtdBoi2216=RMenu:DeleteType("evLtdBoi2216", true)

        end
    end
end
