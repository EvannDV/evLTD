ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockEat15 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750

                for k in pairs {vector3(545.0,2668.6345214844,42.15650177002)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(545.0,2668.6345214844,42.15650177002)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 545.0,2668.6345214844,42.15650177002-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 174, 219, 242, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au rayon")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        ESX.TriggerServerCallback('ev:rayoneat15', function(item)
                            evStockEat15 = item
                        end)
                        evLTDRayon15()
                    end
                end

            end

    Citizen.Wait(wait)
    end
end)








function evLTDRayon15()

    local ltdRayon15 = RageUI.CreateMenu("Rayon Nourriture", "intéractions")

    RageUI.Visible(ltdRayon15, not RageUI.Visible(ltdRayon15))

    while ltdRayon15 do


        Citizen.Wait(0)
        RageUI.IsVisible(ltdRayon15, true, true, true, function()

            if #evStockEat15 >= 1 then
                RageUI.Separator("~g~↓~s~   En vente   ~g~↓~s~")

                for k,v in pairs(evStockEat15) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "~g~"..v.price.." $"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            local loca = "Ltd 15"
                            TriggerServerEvent('ev:BuyLtd', v.price, v.item, cb, v.label, loca)

                        end
                    end)
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd15' then
                        RageUI.ButtonWithStyle("Définir le prix de : ~r~"..v.label, nil, {RightLabel = "🔓"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                priceDefine = Keyboard("Combien ?", "",20)
                                RageUI.CloseAll()
                                local loca = "Ltd 15"
                                TriggerServerEvent('ev:AddPrice', priceDefine, v.item, loca)

                            end
                        end)
                    end
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end





        
        end)
        if not RageUI.Visible(ltdRayon15) then
            ltdRayon15=RMenu:DeleteType("ltdRayon15", true)

        end
    end
end


