ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockEat7 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd7' then
                for k in pairs {vector3(-1221.611328125,-908.04235839844,12.326347351074)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(-1221.611328125,-908.04235839844,12.326347351074)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, -1221.611328125,-908.04235839844,12.326347351074-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 0, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au panel")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        evAddEat7()
                    end
                end
            end
            end

    Citizen.Wait(wait)
    end
end)




------------ Menu Add Items 


function evAddEat7()

    local addeat7 = RageUI.CreateMenu("Panel des Stocks", "intéractions")
    local subnourri27 = RageUI.CreateSubMenu(addeat7, "Rayon Nourriture", "intéractions")
    local subinv27 = RageUI.CreateSubMenu(subnourri27, "Votre inventaire", "intéractions")
    local subinv37 = RageUI.CreateSubMenu(subinv27, "Votre inventaire", "intéractions")
    local subboi17 = RageUI.CreateSubMenu(addeat7, "Rayon Boissons", "intéractions")
    local subinv27boi17 = RageUI.CreateSubMenu(subboi17, "Votre inventaire", "intéractions")
    local subinv27boi1727 = RageUI.CreateSubMenu(subinv27boi17, "Votre inventaire", "intéractions")
    local subtech27 = RageUI.CreateSubMenu(addeat7, "Rayon Boissons", "intéractions")
    local subtech2727 = RageUI.CreateSubMenu(subtech27, "Votre inventaire", "intéractions")
    local subtech272727 = RageUI.CreateSubMenu(subtech2727, "Votre inventaire", "intéractions")
    local subretirNour27 = RageUI.CreateSubMenu(subnourri27, "Rayon Nourriture", "intéractions")
    local subboi2227 = RageUI.CreateSubMenu(subboi17, "Rayon Boissons", "intéractions")
    local subtech27RRR7 = RageUI.CreateSubMenu(subtech27, "Rayon Tech", "intéractions")
    
    
    
    
    

    
    RageUI.Visible(addeat7, not RageUI.Visible(addeat7))

    while addeat7 do


        Citizen.Wait(0)
        RageUI.IsVisible(addeat7, true, true, true, function()




                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Nourriture", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subnourri27)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Boissons", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subboi17)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Tech", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subtech27)


        
        end)

        RageUI.IsVisible(subnourri27, true, true, true, function()



            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv27)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayoneat7', function(item)
                        evStockEat7 = item
                    end)
                end
            end, subretirNour27)
            RageUI.Line()



        end)  
        
        RageUI.IsVisible(subinv27, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv37)
                end
            end



        end)

        RageUI.IsVisible(subinv37, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "nourriture"
                    local loca = "Ltd 7"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subboi17, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv27boi17)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayonboi7', function(item)
                        evStockBoi = item
                    end)
                end
            end, subboi2227)
            RageUI.Line()




        end)

        RageUI.IsVisible(subinv27boi17, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv27boi1727)
                end
            end



        end)


        RageUI.IsVisible(subinv27boi1727, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "boissons"
                    local loca = "Ltd 7"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subtech27, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subtech2727)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayontech7', function(item)
                        evStockTech = item
                    end)
                end
            end, subtech27RRR7)
            RageUI.Line()




        end)

        RageUI.IsVisible(subtech2727, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subtech272727)
                end
            end



        end)

        RageUI.IsVisible(subtech272727, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "tech"
                    local loca = "Ltd 7"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subretirNour27, true, true, true, function()


            if #evStockEat7 >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockEat7) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subboi2227, true, true, true, function()


            if #evStockBoi >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockBoi) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subtech27RRR7, true, true, true, function()


            if #evStockTech >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockTech) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)


        
        

        if not RageUI.Visible(addeat7) and not RageUI.Visible(subnourri27) and not RageUI.Visible(subinv27) and not RageUI.Visible(subinv37) and not RageUI.Visible(subboi17) and not RageUI.Visible(subinv27boi17) and not RageUI.Visible(subinv27boi1727) and not RageUI.Visible(subtech27) and not RageUI.Visible(subtech2727) and not RageUI.Visible(subtech272727) and not RageUI.Visible(subretirNour27) and not RageUI.Visible(subboi2227) and not RageUI.Visible(subtech27RRR7) then
            addeat7=RMenu:DeleteType("addeat7", true)

        end
    end
end





----------Fonction Keyboard


function Keyboard(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end


