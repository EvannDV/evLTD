ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


InvPly = {}
invItem = {}
evStockTech = {}



--------------MARKER

Citizen.CreateThread(function()
    while true do 
        local wait = 750

                for k in pairs {vector3(380.01516723633,326.43969726563,103.56639099121)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(380.01516723633,326.43969726563,103.56639099121)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 380.01516723633,326.43969726563,103.56639099121-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 174, 219, 242, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au rayon")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        ESX.TriggerServerCallback('ev:rayontech', function(item)
                            evStockTech = item
                        end)
                        evLTDTech()
                    end
                end

            end

    Citizen.Wait(wait)
    end
end)

------------------------Menu




function evLTDTech()

    local evLtdTechShop = RageUI.CreateMenu("Rayon Tech", "intéractions")

    RageUI.Visible(evLtdTechShop, not RageUI.Visible(evLtdTechShop))

    while evLtdTechShop do


        Citizen.Wait(0)
        RageUI.IsVisible(evLtdTechShop, true, true, true, function()

            if #evStockTech >= 1 then
                RageUI.Separator("~g~↓~s~   En vente   ~g~↓~s~")

                for k,v in pairs(evStockTech) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "~g~"..v.price.." $"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            local loca = "Ltd 1"
                            TriggerServerEvent('ev:BuyLtd', v.price, v.item, cb, v.label, loca)

                        end
                    end)
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd1' then
                        RageUI.ButtonWithStyle("Définir le prix de : ~r~"..v.label, nil, {RightLabel = "🔓"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                priceDefine = Keyboard("Combien ?", "",20)
                                RageUI.CloseAll()
                                local loca = "Ltd 1"
                                TriggerServerEvent('ev:AddPrice', priceDefine, v.item, loca)

                            end
                        end)
                    end
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end





        
        end)
        if not RageUI.Visible(evLtdTechShop) then
            evLtdTechShop=RMenu:DeleteType("evLtdTechShop", true)

        end
    end
end