ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


RegisterCommand('evLtd', function()
    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd1' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd2' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd3' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd4' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd5' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd6' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd7' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd8' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd9' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd10' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd11' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd12' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd13' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd14' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd15' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd16' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd17' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd18' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd19' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd20' or ESX.PlayerData.job or ESX.PlayerData.job.name == 'ltd21' then
        evF6Ltd()
    end
end)
RegisterKeyMapping('evLtd','Ouvrir le F6 Ltd', 'keyboard', 'F6')



------------------------Menu




function evF6Ltd()

    local evF6LtdShop = RageUI.CreateMenu("Ltd", "intéractions")
    local subAnnonces = RageUI.CreateSubMenu(evF6LtdShop, "Annonces", "intéractions")
    

    RageUI.Visible(evF6LtdShop, not RageUI.Visible(evF6LtdShop))

    while evF6LtdShop do


        Citizen.Wait(0)
        RageUI.IsVisible(evF6LtdShop, true, true, true, function()

            RageUI.ButtonWithStyle("~g~→~s~ Annonces", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
            end, subAnnonces)
            



        
        end)


        RageUI.IsVisible(subAnnonces, true, true, true, function()

            RageUI.ButtonWithStyle("~g~→~s~ Disponible", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    local ltdP = Keyboard("Votre Ltd :", "", 25)
                    TriggerServerEvent('evJobLtd:Dispo', ltdP)
                end
            end)
            RageUI.ButtonWithStyle("~g~→~s~ Indisponible", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    local ltdP = Keyboard("Votre Ltd :", "", 25)
                    TriggerServerEvent('evJobLtd:Indispo', ltdP)
                end
            end)
            RageUI.ButtonWithStyle("~g~→~s~ Personnalisé", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    local ltdP = Keyboard("Votre Ltd :", "", 25)
                    local tapK = Keyboard("Votre Annonce :", "", 25)
                    TriggerServerEvent('evJobLtd:Perso', tapK, ltdP)
                end
            end)



        
        end)




        if not RageUI.Visible(evF6LtdShop) and not RageUI.Visible(subAnnonces) then
            evF6LtdShop=RMenu:DeleteType("evF6LtdShop", true)
        end
    end
end




-------------------------------------------------------






----------------- BLIPS

CreateThread(function()

    for _, info in pairs(Config.blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 0.7)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
        end
    end)