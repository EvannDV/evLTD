ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockEat18 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd18' then
                for k in pairs {vector3(1392.2362060547,3606.2629394531,34.980918884277)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(1392.2362060547,3606.2629394531,34.980918884277)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 1392.2362060547,3606.2629394531,34.980918884277-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 0, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au panel")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        evAddEat18()
                    end
                end
            end
            end

    Citizen.Wait(wait)
    end
end)




------------ Menu Add Items 


function evAddEat18()

    local addeat18 = RageUI.CreateMenu("Panel des Stocks", "intéractions")
    local subnourri218 = RageUI.CreateSubMenu(addeat18, "Rayon Nourriture", "intéractions")
    local subinv2128 = RageUI.CreateSubMenu(subnourri218, "Votre inventaire", "intéractions")
    local subinv318 = RageUI.CreateSubMenu(subinv2128, "Votre inventaire", "intéractions")
    local subboi118 = RageUI.CreateSubMenu(addeat18, "Rayon Boissons", "intéractions")
    local subinv2128boi118 = RageUI.CreateSubMenu(subboi118, "Votre inventaire", "intéractions")
    local subinv2128boi118218 = RageUI.CreateSubMenu(subinv2128boi118, "Votre inventaire", "intéractions")
    local subtech218 = RageUI.CreateSubMenu(addeat18, "Rayon Boissons", "intéractions")
    local subtech2182918 = RageUI.CreateSubMenu(subtech218, "Votre inventaire", "intéractions")
    local subtech2182918218 = RageUI.CreateSubMenu(subtech2182918, "Votre inventaire", "intéractions")
    local subretirNour218 = RageUI.CreateSubMenu(subnourri218, "Rayon Nourriture", "intéractions")
    local subboi22218 = RageUI.CreateSubMenu(subboi118, "Rayon Boissons", "intéractions")
    local subtech218RRR18 = RageUI.CreateSubMenu(subtech218, "Rayon Tech", "intéractions")
    
    
    
    
    

    
    RageUI.Visible(addeat18, not RageUI.Visible(addeat18))

    while addeat18 do


        Citizen.Wait(0)
        RageUI.IsVisible(addeat18, true, true, true, function()




                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Nourriture", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subnourri218)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Boissons", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subboi118)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Tech", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subtech218)


        
        end)

        RageUI.IsVisible(subnourri218, true, true, true, function()



            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv2128)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayoneat18', function(item)
                        evStockEat18 = item
                    end)
                end
            end, subretirNour218)
            RageUI.Line()



        end)  
        
        RageUI.IsVisible(subinv2128, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv318)
                end
            end



        end)

        RageUI.IsVisible(subinv318, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "nourriture"
                    local loca = "Ltd 18"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subboi118, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv2128boi118)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayonboi18', function(item)
                        evStockBoi = item
                    end)
                end
            end, subboi22218)
            RageUI.Line()




        end)

        RageUI.IsVisible(subinv2128boi118, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv2128boi118218)
                end
            end



        end)


        RageUI.IsVisible(subinv2128boi118218, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "boissons"
                    local loca = "Ltd 18"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subtech218, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subtech2182918)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayontech18', function(item)
                        evStockTech = item
                    end)
                end
            end, subtech218RRR18)
            RageUI.Line()




        end)

        RageUI.IsVisible(subtech2182918, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subtech2182918218)
                end
            end



        end)

        RageUI.IsVisible(subtech2182918218, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "tech"
                    local loca = "Ltd 18"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subretirNour218, true, true, true, function()


            if #evStockEat18 >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockEat18) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subboi22218, true, true, true, function()


            if #evStockBoi >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockBoi) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subtech218RRR18, true, true, true, function()


            if #evStockTech >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockTech) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)


        
        

        if not RageUI.Visible(addeat18) and not RageUI.Visible(subnourri218) and not RageUI.Visible(subinv2128) and not RageUI.Visible(subinv318) and not RageUI.Visible(subboi118) and not RageUI.Visible(subinv2128boi118) and not RageUI.Visible(subinv2128boi118218) and not RageUI.Visible(subtech218) and not RageUI.Visible(subtech2182918) and not RageUI.Visible(subtech2182918218) and not RageUI.Visible(subretirNour218) and not RageUI.Visible(subboi22218) and not RageUI.Visible(subtech218RRR18) then
            addeat18=RMenu:DeleteType("addeat18", true)

        end
    end
end





----------Fonction Keyboard


function Keyboard(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end


