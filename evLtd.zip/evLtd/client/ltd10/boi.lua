ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockBoi10 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750

                for k in pairs {vector3(-1829.1123046875,786.28668212891,138.31988525391)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(-1829.1123046875,786.28668212891,138.31988525391)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, -1829.1123046875,786.28668212891,138.31988525391-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 174, 219, 242, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au rayon")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        ESX.TriggerServerCallback('ev:rayonboi10', function(item)
                            evStockBoi10 = item
                        end)
                        evLtd2Boi10()
                    end
                end

            end

    Citizen.Wait(wait)
    end
end)








function evLtd2Boi10()

    local evLtdBoi2210 = RageUI.CreateMenu("Rayon Boissons", "intéractions")

    RageUI.Visible(evLtdBoi2210, not RageUI.Visible(evLtdBoi2210))

    while evLtdBoi2210 do


        Citizen.Wait(0)
        RageUI.IsVisible(evLtdBoi2210, true, true, true, function()

            if #evStockBoi10 >= 1 then
                RageUI.Separator("~g~↓~s~   En vente   ~g~↓~s~")

                for k,v in pairs(evStockBoi10) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "~g~"..v.price.." $"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            local loca = "Ltd 10"
                            TriggerServerEvent('ev:BuyLtd', v.price, v.item, cb, v.label, loca)

                        end
                    end)
                    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd10' then
                        RageUI.ButtonWithStyle("Définir le prix de : ~r~"..v.label, nil, {RightLabel = "🔓"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                priceDefine = Keyboard("Combien ?", "",20)
                                RageUI.CloseAll()
                                local loca = "Ltd 10"
                                TriggerServerEvent('ev:AddPrice', priceDefine, v.item, loca)

                            end
                        end)
                    end
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end





        
        end)
        if not RageUI.Visible(evLtdBoi2210) then
            evLtdBoi2210=RMenu:DeleteType("evLtdBoi2210", true)

        end
    end
end
