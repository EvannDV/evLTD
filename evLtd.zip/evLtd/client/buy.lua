ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)


evListLtd = {}
evUrLtd = {}

Citizen.CreateThread(function()
    while true do 
        local wait = 750

                for k in pairs {vector3(249.05107116699,212.41841125488,106.2868270874)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(249.05107116699,212.41841125488,106.2868270874)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 249.05107116699,212.41841125488,106.2868270874-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 0, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au panel")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        ESX.TriggerServerCallback('ev:list', function(qui)
                            evListLtd = qui
                        end)
                        buyLtd()
                    end
                end
            end

    Citizen.Wait(wait)
    end
end)







function buyLtd()

    local buyLtd2 = RageUI.CreateMenu("LTD", "vente/achat")

    RageUI.Visible(buyLtd2, not RageUI.Visible(buyLtd2))

    while buyLtd2 do


        Citizen.Wait(0)
        RageUI.IsVisible(buyLtd2, true, true, true, function()

            ESX.TriggerServerCallback('ev:urs', function(your)
                evUrLtd = your
            end)
                RageUI.Separator("~g~↓~s~   En vente   ~g~↓~s~")

                for i = 1, #evListLtd, 1 do
                    if evListLtd[i].boss == "invendu" then
                        RageUI.ButtonWithStyle(evListLtd[i].ltd, nil, {RightLabel = "~b~"..evListLtd[i].price.." $"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                local ouinon = Keyboard("Voulez vous vrm acheter ce LTD ? (oui/non)", "",20)
                                if ouinon == "oui" or ouinon == "OUI" then
                                    TriggerServerEvent("ev:buyaltd", evListLtd[i].price, evListLtd[i].ltd)
                                    RageUI.CloseAll()
                                else
                                    ESX.ShowNotification("Vous venez d'annuler !")
                                    RageUI.CloseAll()
                                end

                            end
                        end)
                    end
                end


                RageUI.Separator("~g~↓~s~   Vendu   ~g~↓~s~")


                for i = 1, #evListLtd, 1 do
                    if evListLtd[i].boss ~= "invendu" then
                        RageUI.ButtonWithStyle(evListLtd[i].ltd, nil, {RightLabel = "Propriétaire : ~b~"..evListLtd[i].boss}, true, function(Hovered, Active, Selected)
                            if Selected then
                                ESX.ShowNotification("~r~Ce ltd appartient déja à ~s~"..evListLtd[i].boss)
                            end
                        end)
                    end
                end
                if evUrLtd ~= "non" then
                    for i = 1, #evUrLtd, 1 do
                        RageUI.ButtonWithStyle("vendre votre Ltd ~y~("..evUrLtd[i].ltd..")~s~", "~o~ATTENTION : Choisissez bien votre prix vous ne pourrez pas revenir dessus !", {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                local price = Keyboard("A quel prix ?", "",20)
                                local ltd = evUrLtd[i].ltd
                                TriggerServerEvent('ev:SellLtd', price, ltd)
                            end
                        end)
                    end
                end



        
        end)
        if not RageUI.Visible(buyLtd2) then
            buyLtd2=RMenu:DeleteType("buyLtd2", true)
            evUrLtd = {}
            evListLtd = {}

        end
    end
end






RegisterNetEvent('pointBro')
AddEventHandler('pointBro', function(ltd)

    if ltd == "ltd1" then
        local coords = vector3(375.15155029297,328.98937988281,103.56636047363)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd2" then
        local coords = vector3(1164.2309570313,-320.09643554688,69.205062866211)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd3" then
        local coords = vector3(1134.5620117188,-979.68420410156,46.415840148926)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd4" then
        local coords = vector3(25.196998596191,-1344.0408935547,29.497024536133)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd5" then
        local coords = vector3(-44.677379608154,-1755.8508300781,29.420999526978)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd6" then
        local coords = vector3(-706.08917236328,-910.92761230469,19.215591430664)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd7" then
        local coords = vector3(-1223.9127197266,-909.77758789063,12.326355934143)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd9" then
        local coords = vector3(-1484.4783935547,-379.94741821289,40.163398742676)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd10" then
        local coords = vector3(-1822.3809814453,796.23571777344,138.10565185547)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd11" then
        local coords = vector3(-2966.5112304688,388.52746582031,15.043314933777)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd12" then
        local coords = vector3(-3042.5327148438,584.20257568359,7.9089293479919)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd13" then
        local coords = vector3(-3245.5571289063,1001.0596923828,12.830714225769)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd14" then
        local coords = vector3(2553.7880859375,381.50805664063,108.62296295166)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd15" then
        local coords = vector3(548.77209472656,2668.0239257813,42.156494140625)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd16" then
        local coords = vector3(1168.6069335938,2710.4284667969,38.157703399658)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd17" then
        local coords = vector3(2675.2509765625,3281.0705566406,55.241138458252)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd18" then
        local coords = vector3(1389.6785888672,3605.177734375,34.980922698975)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd19" then
        local coords = vector3(1958.5122070313,3742.7319335938,32.343746185303)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd20" then
        local coords = vector3(1700.3662109375,4921.1083984375,42.063629150391)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    elseif ltd == "ltd21" then
        local coords = vector3(1730.0827636719,6417.9555664063,35.037231445313)
        local blip = AddBlipForCoord(coords)
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 2)
        ESX.ShowNotification("Un point Gps vous a été placé à votre LTD !")
        Citizen.Wait(120000)
        RemoveBlip(blip)
        ClearAllBlipRoutes()
    end
end)