ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

evStockEat21 = {}


Citizen.CreateThread(function()
    while true do 
        local wait = 750
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ltd21' then
                for k in pairs {vector3(1728.2551269531,6415.994140625,35.037223815918)} do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = {vector3(1728.2551269531,6415.994140625,35.037223815918)}
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)

                if dist <= 15 then 
                    wait = 0
                    DrawMarker(6, 1728.2551269531,6415.994140625,35.037223815918-0.99, 0.0, 0.0, 0.0, -90, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 0, 170, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist <= 1.0 then 
                    wait = 0

                    AddTextEntry("HELP", "Appuyez sur ~INPUT_CONTEXT~ ~s~pour accéder au panel")
                    DisplayHelpTextThisFrame("HELP", false)
                    if IsControlJustPressed(1, 51) then 
                        evAddEat21()
                    end
                end
            end
            end

    Citizen.Wait(wait)
    end
end)




------------ Menu Add Items 


function evAddEat21()

    local addeat21 = RageUI.CreateMenu("Panel des Stocks", "intéractions")
    local subnourri221 = RageUI.CreateSubMenu(addeat21, "Rayon Nourriture", "intéractions")
    local subinv2121 = RageUI.CreateSubMenu(subnourri221, "Votre inventaire", "intéractions")
    local subinv321 = RageUI.CreateSubMenu(subinv2121, "Votre inventaire", "intéractions")
    local subboi121 = RageUI.CreateSubMenu(addeat21, "Rayon Boissons", "intéractions")
    local subinv2121boi121 = RageUI.CreateSubMenu(subboi121, "Votre inventaire", "intéractions")
    local subinv2121boi12121821 = RageUI.CreateSubMenu(subinv2121boi121, "Votre inventaire", "intéractions")
    local subtech221 = RageUI.CreateSubMenu(addeat21, "Rayon Boissons", "intéractions")
    local subtech2212921 = RageUI.CreateSubMenu(subtech221, "Votre inventaire", "intéractions")
    local subtech2212921221 = RageUI.CreateSubMenu(subtech2212921, "Votre inventaire", "intéractions")
    local subretirNour2222222221 = RageUI.CreateSubMenu(subnourri221, "Rayon Nourriture", "intéractions")
    local subboi22221 = RageUI.CreateSubMenu(subboi121, "Rayon Boissons", "intéractions")
    local subtech221RRR21 = RageUI.CreateSubMenu(subtech221, "Rayon Tech", "intéractions")
    
    
    
    
    

    
    RageUI.Visible(addeat21, not RageUI.Visible(addeat21))

    while addeat21 do


        Citizen.Wait(0)
        RageUI.IsVisible(addeat21, true, true, true, function()




                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Nourriture", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subnourri221)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Boissons", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subboi121)
                    RageUI.ButtonWithStyle("~g~→~s~ Rayon Tech", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                    end, subtech221)


        
        end)

        RageUI.IsVisible(subnourri221, true, true, true, function()



            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv2121)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayoneat21', function(item)
                        evStockEat21 = item
                    end)
                end
            end, subretirNour221)
            RageUI.Line()



        end)  
        
        RageUI.IsVisible(subinv2121, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv321)
                end
            end



        end)

        RageUI.IsVisible(subinv321, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "nourriture"
                    local loca = "Ltd 21"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subboi121, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subinv2121boi121)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayonboi21', function(item)
                        evStockBoi = item
                    end)
                end
            end, subboi22221)
            RageUI.Line()




        end)

        RageUI.IsVisible(subinv2121boi121, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subinv2121boi12121821)
                end
            end



        end)


        RageUI.IsVisible(subinv2121boi12121821, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "boissons"
                    local loca = "Ltd 21"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subtech221, true, true, true, function()


            RageUI.Line()
            RageUI.ButtonWithStyle("~g~→~s~ Mettre en Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
            end, subtech2212921)
            RageUI.ButtonWithStyle("~g~→~s~ Retirer du Rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    ESX.TriggerServerCallback('ev:rayontech21', function(item)
                        evStockTech = item
                    end)
                end
            end, subtech221RRR21)
            RageUI.Line()




        end)

        RageUI.IsVisible(subtech2212921, true, true, true, function()




            test = {}


            RageUI.Separator("↓     ~g~Inventaire~s~     ↓")

 

            ESX.PlayerData = ESX.GetPlayerData()
            for i = 1, #ESX.PlayerData.inventory do
                if ESX.PlayerData.inventory[i].count > 0 then
                    RageUI.ButtonWithStyle('~y~→~s~ [~r~' ..ESX.PlayerData.inventory[i].count.. '~s ~] - ~s~' ..ESX.PlayerData.inventory[i].label, nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
                        if (Selected) then 
                            test.evLabel = ESX.PlayerData.inventory[i].label
                            test.NumberEv = ESX.PlayerData.inventory[i].count
                            test.ItemSelected = ESX.PlayerData.inventory[i]
                        end 
                    end, subtech2212921221)
                end
            end



        end)

        RageUI.IsVisible(subtech2212921221, true, true, true, function()


            RageUI.ButtonWithStyle("~y~→~s~ Mettre dans le rayon", nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local label = test.evLabel
                    local number = test.NumberEv
                    local itemS = test.ItemSelected.name
                    local howMany = Keyboard("Combien ?", "",20)
                    local cat = "tech"
                    local loca = "Ltd 21"
                    if tonumber(howMany) <= test.NumberEv then
                        TriggerServerEvent('ev:AddItem', itemS, howMany, label,cat, loca)
                        RageUI.CloseAll()
                    else
                        ESX.ShowNotification("~r~Vous n'en avez pas assez !")
                    end

                end
            end) 




        end)

        RageUI.IsVisible(subretirNour221, true, true, true, function()


            if #evStockEat21 >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockEat21) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subboi22221, true, true, true, function()


            if #evStockBoi >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockBoi) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)

        RageUI.IsVisible(subtech221RRR21, true, true, true, function()


            if #evStockTech >= 1 then
                RageUI.Separator("~g~↓~s~   Retirer   ~g~↓~s~")
    
                for k,v in pairs(evStockTech) do
                    RageUI.ButtonWithStyle("[~b~"..v.number.."~s~]~s~ "..v.label, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            local cb = Keyboard("Combien ?", "",20)
                            RageUI.CloseAll()
                            TriggerServerEvent('ev:Retirer', v.item, cb, v.label)
    
                        end
                    end)
                end
            else
                RageUI.Separator("")
                RageUI.Separator("~r~Le rayon est vide~s~")
                RageUI.Separator("")
            end 




        end)


        
        

        if not RageUI.Visible(addeat21) and not RageUI.Visible(subnourri221) and not RageUI.Visible(subinv2121) and not RageUI.Visible(subinv321) and not RageUI.Visible(subboi121) and not RageUI.Visible(subinv2121boi121) and not RageUI.Visible(subinv2121boi12121821) and not RageUI.Visible(subtech221) and not RageUI.Visible(subtech2212921) and not RageUI.Visible(subtech2212921221) and not RageUI.Visible(subretirNour221) and not RageUI.Visible(subboi22221) and not RageUI.Visible(subtech221RRR21) then
            addeat21=RMenu:DeleteType("addeat21", true)

        end
    end
end





----------Fonction Keyboard


function Keyboard(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end


