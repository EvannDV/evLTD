





CREATE TABLE `ltd_eat` (
  `item` varchar(255) NOT NULL,
  `number` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `categorie` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `loca` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;




CREATE TABLE `ltd_dir` (
  `dir` varchar(255) NOT NULL DEFAULT 'invendu',
  `ltd` varchar(255) NOT NULL,
  `price` int(11) NOT NULL DEFAULT 100000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `ltd_dir` (`dir`, `ltd`, `price`) VALUES
('invendu', 'ltd1', 100000),
('invendu', 'ltd10', 100000),
('invendu', 'ltd11', 100000),
('invendu', 'ltd12', 100000),
('invendu', 'ltd13', 100000),
('invendu', 'ltd14', 100000),
('invendu', 'ltd15', 100000),
('invendu', 'ltd16', 100000),
('invendu', 'ltd17', 100000),
('invendu', 'ltd18', 100000),
('invendu', 'ltd19', 100000),
('invendu', 'ltd2', 100000),
('invendu', 'ltd20', 100000),
('invendu', 'ltd21', 100000),
('invendu', 'ltd3', 100000),
('invendu', 'ltd4', 100000),
('invendu', 'ltd5', 100000),
('invendu', 'ltd6', 100000),
('invendu', 'ltd7', 100000),
('invendu', 'ltd8', 100000),
('invendu', 'ltd9', 100000);


ALTER TABLE `ltd_dir`
  ADD PRIMARY KEY (`ltd`);
COMMIT;






--
--  LTD 1 
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd1', 'ltd1', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd1', 'ltd1', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd1', 'ltd1', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd1', 'ltd1')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd1',0,'recrue','Recrue',12,'{}','{}'),
	('ltd1',1,'medium',"Medium",24,'{}','{}'),
	('ltd1',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd1',3,'boss',"Patron",48,'{}','{}')
;



--
--  LTD 2
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd2', 'ltd2', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd2', 'ltd2', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd2', 'ltd2', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd2', 'ltd2')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd2',0,'recrue','Recrue',12,'{}','{}'),
	('ltd2',1,'medium',"Medium",24,'{}','{}'),
	('ltd2',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd2',3,'boss',"Patron",48,'{}','{}')
;









--
--  LTD 3
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd3', 'ltd3', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd3', 'ltd3', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd3', 'ltd3', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd3', 'ltd3')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd3',0,'recrue','Recrue',12,'{}','{}'),
	('ltd3',1,'medium',"Medium",24,'{}','{}'),
	('ltd3',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd3',3,'boss',"Patron",48,'{}','{}')
;




--
--  LTD 4
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd4', 'ltd4', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd4', 'ltd4', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd4', 'ltd4', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd4', 'ltd4')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd4',0,'recrue','Recrue',12,'{}','{}'),
	('ltd4',1,'medium',"Medium",24,'{}','{}'),
	('ltd4',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd4',3,'boss',"Patron",48,'{}','{}')
;







--
--  LTD 5
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd5', 'ltd5', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd5', 'ltd5', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd5', 'ltd5', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd5', 'ltd5')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd5',0,'recrue','Recrue',12,'{}','{}'),
	('ltd5',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd5',3,'boss',"Patron",48,'{}','{}')
;






--
--  LTD 6
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd6', 'ltd6', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd6', 'ltd6', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd6', 'ltd6', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd6', 'ltd6')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd6',0,'recrue','Recrue',12,'{}','{}'),
	('ltd6',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd6',3,'boss',"Patron",48,'{}','{}')
;








--
--  LTD 7
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd7', 'ltd7', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd7', 'ltd7', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd7', 'ltd7', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd7', 'ltd7')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd7',0,'recrue','Recrue',12,'{}','{}'),
	('ltd7',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd7',3,'boss',"Patron",48,'{}','{}')
;















--
--  LTD 9
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd9', 'ltd9', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd9', 'ltd9', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd9', 'ltd9', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd9', 'ltd9')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd9',0,'recrue','Recrue',12,'{}','{}'),
	('ltd9',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd9',3,'boss',"Patron",48,'{}','{}')
;








--
--  LTD 10
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd10', 'ltd10', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd10', 'ltd10', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd10', 'ltd10', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd10', 'ltd10')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd10',0,'recrue','Recrue',12,'{}','{}'),
	('ltd10',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd10',3,'boss',"Patron",48,'{}','{}')
;






--
--  LTD 11
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd11', 'ltd11', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd11', 'ltd11', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd11', 'ltd11', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd11', 'ltd11')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd11',0,'recrue','Recrue',12,'{}','{}'),
	('ltd11',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd11',3,'boss',"Patron",48,'{}','{}')
;




--
--  LTD 12
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd12', 'ltd12', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd12', 'ltd12', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd12', 'ltd12', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd12', 'ltd12')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd12',0,'recrue','Recrue',12,'{}','{}'),
	('ltd12',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd12',3,'boss',"Patron",48,'{}','{}')
;







--
--  LTD 13
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd13', 'ltd13', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd13', 'ltd13', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd13', 'ltd13', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd13', 'ltd13')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd13',0,'recrue','Recrue',12,'{}','{}'),
	('ltd13',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd13',3,'boss',"Patron",48,'{}','{}')
;






--
--  LTD 14
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd14', 'ltd14', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd14', 'ltd14', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd14', 'ltd14', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd14', 'ltd14')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd14',0,'recrue','Recrue',12,'{}','{}'),
	('ltd14',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd14',3,'boss',"Patron",48,'{}','{}')
;





--
--  LTD 15
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd15', 'ltd15', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd15', 'ltd15', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd15', 'ltd15', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd15', 'ltd15')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd15',0,'recrue','Recrue',12,'{}','{}'),
	('ltd15',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd15',3,'boss',"Patron",48,'{}','{}')
;






--
--  LTD 16
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd16', 'ltd16', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd16', 'ltd16', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd16', 'ltd16', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd16', 'ltd16')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd16',0,'recrue','Recrue',12,'{}','{}'),
	('ltd16',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd16',3,'boss',"Patron",48,'{}','{}')
;









--
--  LTD 17
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd17', 'ltd17', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd17', 'ltd17', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd17', 'ltd17', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd17', 'ltd17')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd17',0,'recrue','Recrue',12,'{}','{}'),
	('ltd17',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd17',3,'boss',"Patron",48,'{}','{}')
;









--
--  LTD 18
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd18', 'ltd18', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd18', 'ltd18', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd18', 'ltd18', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd18', 'ltd18')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd18',0,'recrue','Recrue',12,'{}','{}'),
	('ltd18',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd18',3,'boss',"Patron",48,'{}','{}')
;







--
--  LTD 19
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd19', 'ltd19', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd19', 'ltd19', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd19', 'ltd19', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd19', 'ltd19')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd19',0,'recrue','Recrue',12,'{}','{}'),
	('ltd19',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd19',3,'boss',"Patron",48,'{}','{}')
;




--
--  LTD 20
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd20', 'ltd20', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd20', 'ltd20', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd20', 'ltd20', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd20', 'ltd20')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd20',0,'recrue','Recrue',12,'{}','{}'),
	('ltd20',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd20',3,'boss',"Patron",48,'{}','{}')
;






--
--  LTD 21
--


INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_ltd21', 'ltd21', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_ltd21', 'ltd21', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_ltd21', 'ltd21', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('ltd21', 'ltd21')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('ltd21',0,'recrue','Recrue',12,'{}','{}'),
	('ltd21',2,'ce','chef Equipe',36,'{}','{}'),
	('ltd21',3,'boss',"Patron",48,'{}','{}')
;