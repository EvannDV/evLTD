ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)


ESX.RegisterServerCallback('ev:rayoneat', function(source, cb)
    local ltdeat = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 1"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat2', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 2"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat3', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 3"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat4', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 4"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat5', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 5"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat6', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 6"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat7', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 7"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat9', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 9"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat10', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 10"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat11', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 11"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)



ESX.RegisterServerCallback('ev:rayoneat12', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 12"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat13', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 13"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat14', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 14"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat15', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 15"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat16', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 16"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat17', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 17"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat18', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 18"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayoneat19', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 19"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat20', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 20"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)

ESX.RegisterServerCallback('ev:rayoneat21', function(source, cb)
    local ltdeat2 = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "nourriture", ['@loca'] = "Ltd 21"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdeat2, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdeat2)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 1"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi2', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 2"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi3', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 3"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi4', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 4"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi5', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 5"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi6', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 6"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi7', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 7"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi9', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 9"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi10', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 10"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi11', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 11"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi12', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 12"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi13', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 13"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi14', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 14"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi15', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 15"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi16', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 16"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi17', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 17"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)

ESX.RegisterServerCallback('ev:rayonboi18', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 18"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi19', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 19"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi20', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 20"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayonboi21', function(source, cb)
    local ltdboi = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "boissons", ['@loca'] = "Ltd 21"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdboi, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdboi)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 1"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech2', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 2"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech3', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 3"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech4', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 4"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech5', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 5"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech6', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 6"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech7', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 7"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech9', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 9"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech10', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 10"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech11', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 11"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech12', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 12"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)



ESX.RegisterServerCallback('ev:rayontech13', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 13"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech14', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 14"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech15', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 15"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech16', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 16"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)



ESX.RegisterServerCallback('ev:rayontech17', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 17"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)



ESX.RegisterServerCallback('ev:rayontech18', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 18"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech19', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 19"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)

ESX.RegisterServerCallback('ev:rayontech20', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 20"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)


ESX.RegisterServerCallback('ev:rayontech21', function(source, cb)
    local ltdtech = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE categorie=@cat AND loca=@loca', {['@cat'] = "tech", ['@loca'] = "Ltd 21"}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdtech, {
                item = result[i].item,
                label = result[i].label,
                number = result[i].number,
                price = result[i].price,
                loca = result[i].loca,
            })
        end

        cb(ltdtech)
    end)
end)




RegisterNetEvent('ev:AddItem')
AddEventHandler('ev:AddItem', function(item, number, label, cat, loca)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it AND loca=@loca', {['@it'] = item, ['@loca'] = loca}, function(result)
        print(json.encode(result))
        if json.encode(result) ~= "[]" then

            MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it AND loca=@loca', {['@it'] = item, ['@loca'] = loca}, function(data)
                local numberEvF = data[1].number
                MySQL.Async.execute('UPDATE `ltd_eat` SET `number`=@n  WHERE item=@it', {['@n'] = numberEvF + number, ['@it'] = item}, function(rowsChange)
                    xPlayer.removeInventoryItem(item, number)
                    TriggerClientEvent('esx:showNotification', source, "Vous venez d'ajouter "..number.." "..label.." dans le rayon "..cat)
                end)
            end)


        else
            MySQL.Async.execute('INSERT INTO ltd_eat (item,number,label,categorie,loca) VALUES (@item,@number,@label,@categorie,@loca)',
            {
                ['@item']   = item,
                ['@number'] = number,
                ['@label'] = label,
                ['@categorie'] = cat,
                ['@loca'] = loca
            }, function (rowsChanged)
                xPlayer.removeInventoryItem(item, number)
                TriggerClientEvent('esx:showNotification', source, "Vous venez d'ajouter "..number.." "..label.." dans le rayon "..cat)
            end)
        end
    end)

end)



RegisterNetEvent('ev:AddPrice')
AddEventHandler('ev:AddPrice', function(price, item, loca)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
        MySQL.Async.execute('UPDATE `ltd_eat` SET `price`=@p  WHERE item=@it AND loca=@loca', {['@p'] = price, ['@it'] = item, ['@loca'] = loca}, function(rowsChange)
            TriggerClientEvent('esx:showNotification', source, "Vous venez de définir le prix de ~g~"..item.."~s~ à ~b~"..price.."~s~ $")
        end)
end)


RegisterNetEvent('ev:BuyLtd')
AddEventHandler('ev:BuyLtd', function(price, item, cb, label, loca)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local sousPly = xPlayer.getMoney()
    local finalP = price*cb
    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it AND loca=@loca', {['@it'] = item, ['@loca'] = loca}, function(data)
        local numberEvF = data[1].number
        if tonumber(cb) <= numberEvF then
            if sousPly >= finalP then
                xPlayer.removeMoney(finalP)
                TriggerEvent('esx_addonaccount:getSharedAccount', "society_ltd", function (account)
                    account.addMoney(finalP)
                end)
                xPlayer.addInventoryItem(item, cb)
                MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it', {['@it'] = item}, function(data)
                    local numberEvF = data[1].number
                    MySQL.Async.execute('UPDATE `ltd_eat` SET `number`=@n  WHERE item=@it AND loca=@loca', {['@n'] = numberEvF - cb, ['@it'] = item, ['@loca'] = loca}, function(rowsChange)
                        evCheck(item, loca)
                    end)
                end)
                TriggerClientEvent('esx:showNotification', source, "Vous venez d'acheter ~b~"..cb.."~s~ "..label.." pour ~g~"..finalP.."~s~ $")
            else
                TriggerClientEvent('esx:showNotification', source, "~r~Vous n'avez pas assez d'argent !")
            end
        else
            TriggerClientEvent('esx:showNotification', source, "~r~Il n'y a pas assez en stock !")
        end
    end)
    
end)


function evCheck(item, loca)
    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it AND loca=@loca', {['@it'] = item, ['@loca'] = loca}, function(data)
        local numberEvF2 = data[1].number
        if numberEvF2 == 0 then
            MySQL.Async.execute('DELETE FROM ltd_eat WHERE item = @item', {
                ['@item'] = item
            })
        else
            print("no")
        end
    end)
end

function evCheck2(item)
    MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it', {['@it'] = item}, function(data)
        local numberEvF2 = data[1].number
        if numberEvF2 == 0 then
            MySQL.Async.execute('DELETE FROM ltd_eat WHERE item = @item', {
                ['@item'] = item
            })
        else
            print("no")
        end
    end)
end




RegisterNetEvent('ev:Retirer')
AddEventHandler('ev:Retirer', function(item, cb, label)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

        MySQL.Async.fetchAll('SELECT * FROM ltd_eat WHERE item = @it', {['@it'] = item}, function(data)
            local numberEvF = data[1].number
            if tonumber(cb) <= numberEvF then
                local catEv = data[1].categorie
                MySQL.Async.execute('UPDATE `ltd_eat` SET `number`=@n  WHERE item=@it AND categorie = @cat', {['@n'] = numberEvF - cb, ['@it'] = item, ['@cat'] = catEv}, function(rowsChange)
                    xPlayer.addInventoryItem(item, cb)
                    TriggerClientEvent('esx:showNotification', source, "Vous venez de retirer ~b~"..cb.."~s~ "..label.." du rayon ~g~"..catEv)
                    evCheck2(item)
                end)
            else
                TriggerClientEvent('esx:showNotification', source, "~r~Pas assez en rayon")
            end
        end)


end)




---------------- Boss Action 
evJobGot = {}

RegisterNetEvent('ev:GetJob')
AddEventHandler('ev:GetJob', function(job)
    local source = source
    evJobGot = job
end)




ESX.RegisterServerCallback('ev:refresh', function(source, cb, accountEv)
    local source = source
        MySQL.Async.fetchAll('SELECT * FROM addon_account_data WHERE account_name = @a', {['a'] = "society_"..evJobGot}, function(data)
            local accountEv = data[1].money
            cb(accountEv)
        end)
end)



RegisterNetEvent('evtest')
AddEventHandler('evtest', function(number, jobPly)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    TriggerEvent('esx_addonaccount:getSharedAccount', "society_"..jobPly, function (account)
        account.addMoney(number)
    end)
    xPlayer.removeMoney(number)
    TriggerClientEvent('esx:showNotification', source, "Vous venez de déposer ~b~"..number.."~s~ $")
end)

RegisterNetEvent('evtest2')
AddEventHandler('evtest2', function(number2, jobPly)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    TriggerEvent('esx_addonaccount:getSharedAccount', "society_"..jobPly, function (account)
        account.removeMoney(number2)
    end)
    xPlayer.addMoney(number2)
    TriggerClientEvent('esx:showNotification', source, "Vous venez de retirer ~b~"..number2.."~s~ $")
end)








RegisterServerEvent('ev:rank')
AddEventHandler('ev:rank', function(target, job)
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local xTarget = ESX.GetPlayerFromId(target)

  	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
  	xTarget.setJob(job, tonumber(xTarget.job.grade) + 1)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été promu")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été promu !")
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'êtes pas patron ou le joueur ne peut pas être promu.")

  end
end)



RegisterServerEvent('ev:derank')
AddEventHandler('ev:derank', function(target, job)
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local xTarget = ESX.GetPlayerFromId(target)

  	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
  	xTarget.setJob(job, tonumber(xTarget.job.grade) - 1)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été rétrograder")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été rétrograder !")
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'êtes pas patron ou le joueur ne peut pas être rétrograder.")

  end
end)




RegisterServerEvent('ev:recruter')
AddEventHandler('ev:recruter', function(target, job)
	local source = source
  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)

  
  	if xPlayer.job.grade_name == 'boss' then
  	xTarget.setJob(job, 0)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été recruté")
  	TriggerClientEvent('esx:showNotification', target, "Bienvenue dans l'entreprise !")
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'êtes pas patron...")
	end
end)


RegisterServerEvent('ev:virer')
AddEventHandler('ev:virer', function(target)
	local source = source
  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)

  
  	if xPlayer.job.grade_name == 'boss' then
  	xTarget.setJob("unemployed", 0)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été viré")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été viré !")
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'êtes pas patron...")
	end
end)




------------- Annonces F6 


RegisterServerEvent('evJobLtd:Dispo')
AddEventHandler('evJobLtd:Dispo', function(ltd)
	local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    local xPlayers = ESX.GetPlayers()
    for i=1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], ltd, '~y~Annonce', 'Un employé du Ltd est maintenant ~g~Disponible', 'CHAR_SOCIAL_CLUB', 1)
    end
end)

RegisterServerEvent('evJobLtd:Indispo')
AddEventHandler('evJobLtd:Indispo', function(ltd)
	local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    local xPlayers = ESX.GetPlayers()
    for i=1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], ltd, '~y~Annonce', 'Les Ltd passe en ~p~service automatique !', 'CHAR_SOCIAL_CLUB', 1)
    end
end)

RegisterServerEvent('evJobLtd:Perso')
AddEventHandler('evJobLtd:Perso', function(tap, ltd)
	local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    local xPlayers = ESX.GetPlayers()
    for i=1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], ltd, '~y~Annonce', tap, 'CHAR_SOCIAL_CLUB', 1)
    end
end)





--------------------- ENCHERES 



ESX.RegisterServerCallback('ev:list', function(source, cb)
    local ltdlist = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_dir', {}, function(result)
        for i = 1, #result, 1 do
            table.insert(ltdlist, {
                boss = result[i].dir,
                ltd = result[i].ltd,
                price = result[i].price,
            })
        end

        cb(ltdlist)
    end)
end)


ESX.RegisterServerCallback('ev:urs', function(source, cb)
    local isurs = {}
	local source = source 
	local xPlayer = ESX.GetPlayerFromId(source)
    local name = xPlayer.getName(source)

    MySQL.Async.fetchAll('SELECT * FROM ltd_dir WHERE dir=@dir', {['@dir'] =  name}, function(result)
        if json.encode(result) ~= "[]" then
            for i = 1, #result, 1 do
                table.insert(isurs, {
                    boss = result[i].dir,
                    ltd = result[i].ltd,
                    price = result[i].price,
                })
            end
        else
            isurs = "non"
        end

        cb(isurs)
    end)
end)


RegisterNetEvent('ev:buyaltd')
AddEventHandler('ev:buyaltd', function(price, ltd)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local namePlyBro = xPlayer.getName(source)
    local money = xPlayer.getAccount('bank').money
    if money >= price then
        MySQL.Async.execute('UPDATE `ltd_dir` SET `dir`=@dir WHERE ltd=@ltd', {['@dir'] = namePlyBro, ['@ltd'] = ltd}, function(rowsChange)
            xPlayer.setJob(ltd, 3)
            xPlayer.removeMoney(price)
        end)
        TriggerClientEvent('pointBro', source, ltd)
        TriggerClientEvent('esx:showNotification', source, "Vous venez d'acheter le ~b~"..ltd.."~s~ et vous en êtes maintenant le ~g~patron !")
    else
        TriggerClientEvent('esx:showNotification', source, "~r~Vous n'avez pas assez d'argent en banque !")
    end
end)





RegisterNetEvent('ev:SellLtd')
AddEventHandler('ev:SellLtd', function(price, ltd)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local namePlyBro = xPlayer.getName(source)

    MySQL.Async.execute('UPDATE `ltd_dir` SET `price`=@price WHERE ltd=@ltd AND dir=@dir', {['@price'] = price + evPrice.Add, ['@ltd'] = ltd, ['@dir'] = namePlyBro}, function(rowsChange)
        TriggerClientEvent('esx:showNotification', source, "~r~Vous venez de mettre en vente votre ~g~"..ltd.."~s~ et avez recu votre argent !")
        MySQL.Async.execute('UPDATE `ltd_dir` SET `dir`=@dir WHERE ltd=@ltd', {['@ltd'] = ltd, ['@dir'] = "invendu"}, function(rowsChange)
            xPlayer.setJob("unemployed", 0)
            xPlayer.addMoney(price)
            print("good pour le sell du ltd")
        end)
    end)

end)