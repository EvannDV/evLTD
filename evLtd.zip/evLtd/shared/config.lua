Config = {}
evPrice = {}



Config.blips = {  --> NE PAS TOUCHER TOUS CA
    {title="Ltd", colour=2, id=59, x = -707.41, y = -914.04, z = 19.22},
    {title="Ltd", colour=2, id=59, x = 1135.63, y = -982.07, z = 46.42},
    {title="Ltd", colour=2, id=59, x = 1163.56, y = -323.71, z = 69.21},
    {title="Ltd", colour=2, id=59, x = 373.94, y = 326.69, z = 103.57},
    {title="Ltd", colour=2, id=59, x = 2557.3, y = 382.11, z = 108.62},
    {title="Ltd", colour=2, id=59, x = -3039.85, y = 585.59, z = 7.91},
    {title="Ltd", colour=2, id=59, x = -3241.91, y = 1001.42, z = 12.83},
    {title="Ltd", colour=2, id=59, x = 547.65, y = 2670.88, z = 42.16},
    {title="Ltd", colour=2, id=59, x = 1961.41, y = 3740.89, z = 32.34},
    {title="Ltd", colour=2, id=59, x = 2679.02, y = 3280.67, z = 55.24},
    {title="Ltd", colour=2, id=59, x = 1729.17, y = 6414.94, z = 35.04},
    {title="Ltd", colour=2, id=59, x = -1222.85, y = -907.05, z = 12.33},
    {title="Ltd", colour=2, id=59, x = -1487.17, y = -379.83, z = 40.16},
    {title="Ltd", colour=2, id=59, x = -2968.41, y = 390.05, z = 15.04},
    {title="Ltd", colour=2, id=59, x = 1166.41, y = 2709.31, z = 38.16},
    {title="Ltd", colour=2, id=59, x = -48.52, y = -1757.29, z = 29.42},
    {title="Ltd", colour=2, id=59, x = -1820.86, y = 792.52, z = 138.12},
    {title="Ltd", colour=2, id=59, x = 1698.44, y = 4924.39, z = 42.06},
    {title="Ltd", colour=2, id=59,x = 25.75, y = -1347.30, z = 29.49},
    {title="Ltd", colour=2, id=59,x = 1392.5634765625, y = 3604.6813964844, z = 34.980995178223},
}

 -- LA VOUS POUVEZ MODIFIER --

evPrice = {
    Add = 10000  ---> Argent en plus ajouter au prix de revente du Ltd pour simuler un bénéfice de la bank
}